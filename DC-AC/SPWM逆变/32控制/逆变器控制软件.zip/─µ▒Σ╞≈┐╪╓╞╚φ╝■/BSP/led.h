
#ifndef   LED_H
#define   LED_H

#include "includes.h"


void 		LedInit		(void);			//��ʼ��
void		Led			(INT8S i);	    //����led



#endif





















