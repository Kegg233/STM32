#ifndef   SPK_H
#define   SPK_H


void 		SpkInit			(void);
void		SpkOut			(INT8S i);





#endif
