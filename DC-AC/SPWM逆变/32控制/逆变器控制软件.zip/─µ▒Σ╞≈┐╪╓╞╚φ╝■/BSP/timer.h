#ifndef   TIMER_H
#define   TIMER_H

void 	Time2_2ms		(void);
void Time2Start(void);
void Time2End( void );

#endif
