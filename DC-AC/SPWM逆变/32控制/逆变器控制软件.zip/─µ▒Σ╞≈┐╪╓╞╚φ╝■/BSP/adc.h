#ifndef   ADC_H
#define   ADC_H


void 		ADC_Config		(void);
INT16U 		GetVoltageADC	(void);
void Getk_adc(void);
FP32 GetTemp(void);
FP32 GetBATE(void);
FP32 GetDC310(void);

FP32 GetWenDu(void);
FP32 GetElectric(void);


#endif





